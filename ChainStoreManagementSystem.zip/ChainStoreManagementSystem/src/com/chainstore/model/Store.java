package com.chainstore.model;

public class Store {
    private int id;
    private String storeName;
    private String manager;
    private String address;
    private String storeType;

    public Store() {}

    public Store(int id, String storeName, String manager, String address, String storeType) {
        this.id = id;
        this.storeName = storeName;
        this.manager = manager;
        this.address = address;
        this.storeType = storeType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getStoreType() {
        return storeType;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }
}