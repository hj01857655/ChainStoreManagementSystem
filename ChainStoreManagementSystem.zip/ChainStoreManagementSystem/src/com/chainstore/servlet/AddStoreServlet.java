package com.chainstore.servlet;

import com.chainstore.model.Store;
import com.chainstore.service.StoreService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/addStore")
public class AddStoreServlet extends HttpServlet {
    private StoreService storeService = new StoreService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            storeService.createStoreTable();
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "创建门店表失败，请重试！");
            request.getRequestDispatcher("addStore.jsp").forward(request, response);
            return;
        }

        String storeName = request.getParameter("storeName");
        String manager = request.getParameter("manager");
        String address = request.getParameter("address");
        String storeType = request.getParameter("storeType");

        Store store = new Store();
        store.setStoreName(storeName);
        store.setManager(manager);
        store.setAddress(address);
        store.setStoreType(storeType);

        try {
            storeService.addStore(store);
            response.sendRedirect("queryStore.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "添加门店失败，请重试！");
            request.getRequestDispatcher("addStore.jsp").forward(request, response);
        }
    }
}