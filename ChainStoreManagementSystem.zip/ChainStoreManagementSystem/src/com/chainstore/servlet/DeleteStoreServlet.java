package com.chainstore.servlet;

import com.chainstore.service.StoreService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/deleteStore")
public class DeleteStoreServlet extends HttpServlet {
    private StoreService storeService = new StoreService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        try {
            storeService.deleteStore(id);
            response.sendRedirect("queryStore.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "删除门店失败，请重试！");
            request.getRequestDispatcher("queryStore.jsp").forward(request, response);
        }
    }
}