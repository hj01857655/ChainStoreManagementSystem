package com.chainstore.servlet;

import com.chainstore.model.Store;
import com.chainstore.service.StoreService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/updateStore")
public class UpdateStoreServlet extends HttpServlet {
    private StoreService storeService = new StoreService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String storeName = request.getParameter("storeName");
        String manager = request.getParameter("manager");
        String address = request.getParameter("address");
        String storeType = request.getParameter("storeType");

        Store store = new Store();
        store.setId(id);
        store.setStoreName(storeName);
        store.setManager(manager);
        store.setAddress(address);
        store.setStoreType(storeType);

        try {
            storeService.updateStore(store);
            response.sendRedirect("queryStore.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "更新门店失败，请重试！");
            request.getRequestDispatcher("updateStore.jsp").forward(request, response);
        }
    }
}