package com.chainstore.service;

import com.chainstore.dao.UserDAO;
import com.chainstore.dao.UserDAOImpl;
import com.chainstore.model.User;

import java.sql.SQLException;

public class UserService {
    private UserDAO userDAO = new UserDAOImpl();

    public void createUserTable() throws SQLException {
        userDAO.createUserTable();
    }

    public void registerUser(User user) throws SQLException {
        userDAO.insertUser(user);
    }

    public User loginUser(String username, String password) throws SQLException {
        return userDAO.selectUser(username, password);
    }
}