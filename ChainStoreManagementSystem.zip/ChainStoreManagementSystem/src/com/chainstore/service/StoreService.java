package com.chainstore.service;

import com.chainstore.dao.StoreDAO;
import com.chainstore.dao.StoreDAOImpl;
import com.chainstore.model.Store;

import java.sql.SQLException;
import java.util.List;

public class StoreService {
    private StoreDAO storeDAO = new StoreDAOImpl();

    public void createStoreTable() throws SQLException {
        storeDAO.createStoreTable();
    }

    public void addStore(Store store) throws SQLException {
        storeDAO.insertStore(store);
    }

    public void updateStore(Store store) throws SQLException {
        storeDAO.updateStore(store);
    }

    public void deleteStore(int id) throws SQLException {
        storeDAO.deleteStore(id);
    }

    public List<Store> queryStores(String storeName, String manager, String address, String storeType) throws SQLException {
        return storeDAO.selectStores(storeName, manager, address, storeType);
    }
}