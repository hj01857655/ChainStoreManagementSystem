package com.chainstore.dao;

import com.chainstore.model.Store;
import com.chainstore.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StoreDAOImpl implements StoreDAO {

    @Override
    public void createStoreTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS stores (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "store_name VARCHAR(100) NOT NULL," +
                "manager VARCHAR(50) NOT NULL," +
                "address VARCHAR(255) NOT NULL," +
                "store_type VARCHAR(50) NOT NULL" +
                ")";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.executeUpdate();
        }
    }

    @Override
    public void insertStore(Store store) throws SQLException {
        String sql = "INSERT INTO stores (store_name, manager, address, store_type) VALUES (?,?,?,?)";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, store.getStoreName());
            pstmt.setString(2, store.getManager());
            pstmt.setString(3, store.getAddress());
            pstmt.setString(4, store.getStoreType());
            pstmt.executeUpdate();
        }
    }

    @Override
    public void updateStore(Store store) throws SQLException {
        String sql = "UPDATE stores SET store_name = ?, manager = ?, address = ?, store_type = ? WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, store.getStoreName());
            pstmt.setString(2, store.getManager());
            pstmt.setString(3, store.getAddress());
            pstmt.setString(4, store.getStoreType());
            pstmt.setInt(5, store.getId());
            pstmt.executeUpdate();
        }
    }

    @Override
    public void deleteStore(int id) throws SQLException {
        String sql = "DELETE FROM stores WHERE id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    @Override
    public List<Store> selectStores(String storeName, String manager, String address, String storeType) throws SQLException {
        List<Store> stores = new ArrayList<>();
        String sql = "SELECT * FROM stores WHERE 1=1";
        if (storeName != null && !storeName.isEmpty()) {
            sql += " AND store_name LIKE ?";
        }
        if (manager != null && !manager.isEmpty()) {
            sql += " AND manager LIKE ?";
        }
        if (address != null && !address.isEmpty()) {
            sql += " AND address LIKE ?";
        }
        if (storeType != null && !storeType.isEmpty()) {
            sql += " AND store_type LIKE ?";
        }
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            int paramIndex = 1;
            if (storeName != null && !storeName.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + storeName + "%");
            }
            if (manager != null && !manager.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + manager + "%");
            }
            if (address != null && !address.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + address + "%");
            }
            if (storeType != null && !storeType.isEmpty()) {
                pstmt.setString(paramIndex, "%" + storeType + "%");
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("store_name");
                String mgr = rs.getString("manager");
                String addr = rs.getString("address");
                String type = rs.getString("store_type");
                stores.add(new Store(id, name, mgr, addr, type));
            }
        }
        return stores;
    }
}