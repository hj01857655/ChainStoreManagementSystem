package com.chainstore.dao;

import com.chainstore.model.Store;

import java.sql.SQLException;
import java.util.List;

public interface StoreDAO {
    void createStoreTable() throws SQLException;
    void insertStore(Store store) throws SQLException;
    void updateStore(Store store) throws SQLException;
    void deleteStore(int id) throws SQLException;
    List<Store> selectStores(String storeName, String manager, String address, String storeType) throws SQLException;
}