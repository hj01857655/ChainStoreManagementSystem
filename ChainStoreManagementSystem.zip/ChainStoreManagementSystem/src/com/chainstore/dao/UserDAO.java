package com.chainstore.dao;

import com.chainstore.model.User;

import java.sql.SQLException;

public interface UserDAO {
    void createUserTable() throws SQLException;
    void insertUser(User user) throws SQLException;
    User selectUser(String username, String password) throws SQLException;
}