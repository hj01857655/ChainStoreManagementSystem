/**
 * 
 */
// 添加JavaScript 交互逻辑
// 表单验证 事件监听
document.addEventListener('DOMContentLoaded', function () {
    //给所有表单添加提交前的验证逻辑
    const forms = document.querySelectorAll('form');
    forms.forEach(function (form) {
        form.addEventListener('submit', function (event) {
            const inputs = form.querySelectorAll('input[required]');
            for (let i = 0; i < inputs.length; i++) {
                if (inputs[i].value.trim() === '') {
                    event.preventDefault();
                    alert('请填写必填字段');
                    inputs[i].focus();
                    return;
                }
            }
        });
    });
});